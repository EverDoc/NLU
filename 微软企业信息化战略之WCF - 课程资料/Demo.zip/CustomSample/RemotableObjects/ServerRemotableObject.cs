using System;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Threading;
using System.IO;
using System.Xml;

namespace RemotableObjects
{

    public class ServerRemotableObject
    {
        private DirectoryInfo _hotFolder = null;
        private const string ARCHIVE_FOLDER = "Archive";
        private bool _stop = true;

        public ServerRemotableObject(string hotFolder)
        {
            _hotFolder = new DirectoryInfo(hotFolder);
            if (!_hotFolder.Exists)
            {
                throw new Exception("Hot folder not found.");
            }
        }

        public void Start()
        {
            this._stop = false;

            Thread t = new Thread(p =>
            {
                while (!this._stop)
                {
                    FileInfo[] files = this._hotFolder.GetFiles("Request_*.xml");
                    foreach (FileInfo file in files)
                    {
                        // Parse request
                        using (FileStream sr = file.OpenRead())
                        {
                            XmlReader xr = XmlReader.Create(sr);
                            if (xr.ReadToDescendant("Method"))
                            {
                                string methodName = xr.GetAttribute("Name");
                                if (methodName == "SetMessage")
                                {
                                    // Do request
                                    this.SetMessage(xr.GetAttribute("Message"));
                                }
                            }
                        }

                        // Move to archive
                        file.MoveTo(string.Format(@"{0}\{1}\{2}", this._hotFolder, ARCHIVE_FOLDER, file.Name));
                    }

                    Thread.Sleep(500);
                }
            });
            t.Start();
        }

        public void Stop()
        {
            this._stop = true;
        }

        public void SetMessage(string message)
        {
            Publisher.MessageString = message;
        }

    }
}
