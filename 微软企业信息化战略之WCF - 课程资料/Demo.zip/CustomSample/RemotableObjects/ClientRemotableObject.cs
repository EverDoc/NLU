using System;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Threading;
using System.IO;
using System.Xml;

namespace RemotableObjects
{

    public class ClientRemotableObject
    {
        private DirectoryInfo _hotFolder = null;

        public ClientRemotableObject(string hotFolder)
        {
            _hotFolder = new DirectoryInfo(hotFolder);
            if (!_hotFolder.Exists)
            {
                throw new Exception("Hot folder not found.");
            }
        }

        public void SetMessage(string message)
        {
            XmlDocument sd = new XmlDocument();
            sd.LoadXml(String.Format(@"<Root><Method Name=""SetMessage"" Message=""{0}""/></Root>", message));
            using (FileStream fs = File.OpenWrite(string.Format(@"{0}\Request_{1}.xml", this._hotFolder.FullName, Guid.NewGuid())))
            {
                sd.Save(fs);
            }
        }

    }
}
