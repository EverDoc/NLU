using System;

namespace RemotableObjects
{

    public class Publisher
    {
        private static IObserver Observer;
        
        public static void Attach(IObserver observer)
        {
            Observer = observer;
        }

        public static string MessageString
        {
            set 
            {
                if (Observer != null)
                {
                    Observer.Notify(value);
                }
            }
        }
    }
}
