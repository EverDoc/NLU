using System;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;

namespace RemotableObjects
{

	public class MyRemotableObject : MarshalByRefObject
	{

		public MyRemotableObject()
		{
		
		}

		public void SetMessage(string message)
		{
			Publisher.MessageString = message;
		}

	}
}
